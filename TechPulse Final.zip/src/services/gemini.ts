import { GoogleGenAI, Type } from '@google/genai';
import { CandidateTopic, CriteriaScores, PublishingRationale, MemoryNode, PublishedPost } from '../types.js';

let aiInstance: GoogleGenAI | null = null;

function getAi(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('GEMINI_API_KEY environment variable is not set. Falling back to default heuristics.');
    }
    aiInstance = new GoogleGenAI({
      apiKey: apiKey || 'dummy-key',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiInstance;
}

// 1. Generate supplemental trending candidate topics if needed
export async function generateSupplementalTopics(domainFocus: string): Promise<Array<{ title: string; summary: string; sourceName: string; sourceUrl: string; category: string }>> {
  try {
    const ai = getAi();
    const prompt = `You are the topic discovery engine for TechPulse AI. Generate 4 highly realistic, technical, cutting-edge AI and technology news topics or research developments in the field of "${domainFocus}".
Focus on categories: Machine Learning, Robotics, Edge AI, Open Source AI, AI Hardware, or AI Security.
Avoid fluff, celebrity gossip, or clickbait hype. Focus on real architecture releases, benchmark breakthroughs, novel quantization techniques, robotics control algorithms, or open weights releases.

Return a JSON array of objects with fields:
- title: string
- summary: string (2-3 technical sentences)
- sourceName: string (e.g. ArXiv, Hugging Face, GitHub, OpenAI Research, Anthropic Paper, DeepMind, MIT Tech Review)
- sourceUrl: string
- category: string
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING },
              sourceName: { type: Type.STRING },
              sourceUrl: { type: Type.STRING },
              category: { type: Type.STRING },
            },
            required: ['title', 'summary', 'sourceName', 'sourceUrl', 'category'],
          },
        },
      },
    });

    if (response.text) {
      const items = JSON.parse(response.text.trim());
      return items;
    }
  } catch (e) {
    console.error('Gemini generateSupplementalTopics error:', e);
  }

  // Fallback defaults if API call fails
  return [
    {
      title: 'BitNet b1.58 1-Bit LLM Quantization Architecture Optimization',
      summary: 'Researchers demonstrate 1.58-bit ternary weight quantization retaining full 16-bit LLM performance while reducing GPU VRAM requirements by 82% during edge inference.',
      sourceName: 'ArXiv CS.LG',
      sourceUrl: 'https://arxiv.org/abs/2402.17763',
      category: 'Edge AI',
    },
    {
      title: 'OpenVLA: Open-Source Vision-Language-Action Model for Generalist Robotics',
      summary: 'An open-weight 7B parameter vision-language-action robotics model trained on 970k robot trajectories demonstrating zero-shot cross-robot generalization.',
      sourceName: 'Hugging Face Papers',
      sourceUrl: 'https://huggingface.co/papers/2406.09246',
      category: 'Robotics',
    },
  ];
}

// 2. Evaluate & Score Candidate Topic
export async function scoreCandidateTopic(
  topicTitle: string,
  summary: string,
  sourceName: string,
  category: string,
  minThreshold: number
): Promise<{ criteriaScores: CriteriaScores; totalScore: number; rejectionReason?: string }> {
  try {
    const ai = getAi();
    const systemInstruction = `You are the rigorous Editorial Evaluation Engine for TechPulse AI.
TechPulse AI Persona Principles:
- Core Focus: Machine Learning, Robotics, Edge AI, Open Source AI, AI Hardware, AI Security.
- Editorial Stance: Strongly champions open-source innovation, prefers compact/efficient models over oversized ones, rejects hype/clickbait, demands empirical benchmark evidence.
- Scoring Dimensions (0-100 each):
  1. recency: How recent/timely is this news or research?
  2. innovation: Does it introduce a novel architectural or algorithmic breakthrough?
  3. engineeringValue: Can engineers and researchers immediately apply or learn from this?
  4. educationalValue: High technical depth and clarity for technical readers.
  5. sourceCredibility: Reputable source (ArXiv, HF, GitHub, top research lab vs unknown blog).
  6. novelty: How distinct is this from routine incremental press releases?
  7. communityInterest: Highly relevant to open-source developers & AI researchers.
  8. personaAlignment: Alignment with TechPulse AI principles (open source, efficiency, anti-hype).

Calculate a weighted total score (0-100):
Weighted Score = (recency*0.10 + innovation*0.20 + engineeringValue*0.20 + educationalValue*0.10 + sourceCredibility*0.10 + novelty*0.10 + communityInterest*0.10 + personaAlignment*0.10).

If totalScore < ${minThreshold}, provide a concise, rigorous rejectionReason explaining why it failed editorial standards (e.g. "Lacks open weights or technical paper details; relies heavily on marketing claims.").`;

    const prompt = `Evaluate candidate topic:
Title: "${topicTitle}"
Summary: "${summary}"
Source: "${sourceName}"
Category: "${category}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recency: { type: Type.NUMBER },
            innovation: { type: Type.NUMBER },
            engineeringValue: { type: Type.NUMBER },
            educationalValue: { type: Type.NUMBER },
            sourceCredibility: { type: Type.NUMBER },
            novelty: { type: Type.NUMBER },
            communityInterest: { type: Type.NUMBER },
            personaAlignment: { type: Type.NUMBER },
            totalScore: { type: Type.NUMBER },
            rejectionReason: { type: Type.STRING },
          },
          required: [
            'recency', 'innovation', 'engineeringValue', 'educationalValue',
            'sourceCredibility', 'novelty', 'communityInterest', 'personaAlignment', 'totalScore'
          ],
        },
      },
    });

    if (response.text) {
      const data = JSON.parse(response.text.trim());
      const criteriaScores: CriteriaScores = {
        recency: data.recency,
        innovation: data.innovation,
        engineeringValue: data.engineeringValue,
        educationalValue: data.educationalValue,
        sourceCredibility: data.sourceCredibility,
        novelty: data.novelty,
        communityInterest: data.communityInterest,
        personaAlignment: data.personaAlignment,
      };

      const calculatedScore = Math.round(data.totalScore);
      let rejectionReason = data.rejectionReason;

      if (calculatedScore < minThreshold && !rejectionReason) {
        rejectionReason = `Total score (${calculatedScore}) fell below the editorial publishing threshold of ${minThreshold}. Lacks sufficient open-source engineering value or empirical validation.`;
      }

      return {
        criteriaScores,
        totalScore: calculatedScore,
        rejectionReason: calculatedScore < minThreshold ? rejectionReason : undefined,
      };
    }
  } catch (e) {
    console.error('Gemini scoreCandidateTopic error:', e);
  }

  // Fallback heuristic scoring
  const heuristicScore = 78;
  return {
    criteriaScores: {
      recency: 85,
      innovation: 80,
      engineeringValue: 80,
      educationalValue: 75,
      sourceCredibility: 80,
      novelty: 75,
      communityInterest: 75,
      personaAlignment: 85,
    },
    totalScore: heuristicScore,
  };
}

// 3. Compare with Memory Nodes for Semantic Similarity & Cross-Referencing
export async function checkMemoryContinuity(
  topicTitle: string,
  summary: string,
  memoryNodes: MemoryNode[]
): Promise<{ maxSimilarity: number; referencePostId?: string; referencePostTitle?: string; duplicateReason?: string }> {
  if (memoryNodes.length === 0) {
    return { maxSimilarity: 0 };
  }

  try {
    const ai = getAi();
    const prompt = `Candidate Topic Title: "${topicTitle}"
Summary: "${summary}"

Past Published Posts Memory:
${memoryNodes.map((m, idx) => `[${idx}] Post ID: "${m.publishedPostId}", Headline: "${m.headline}", Summary: "${m.topicSummary}"`).join('\n')}

Analyze semantic similarity between the candidate topic and the past memory posts.
Return JSON object:
- maxSimilarity: number (0 to 100, where 100 means identical topic, 0 means completely unrelated)
- mostSimilarPostId: string or null
- mostSimilarPostTitle: string or null
- isDuplicate: boolean (true if maxSimilarity >= 85)
- duplicateReason: string or null (if duplicate, explain why e.g. "This exact model release was already covered 2 days ago")
- referenceOpportunity: boolean (true if maxSimilarity is between 35 and 80, indicating a great opportunity to cross-reference or build upon the past post)
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            maxSimilarity: { type: Type.NUMBER },
            mostSimilarPostId: { type: Type.STRING },
            mostSimilarPostTitle: { type: Type.STRING },
            isDuplicate: { type: Type.BOOLEAN },
            duplicateReason: { type: Type.STRING },
            referenceOpportunity: { type: Type.BOOLEAN },
          },
          required: ['maxSimilarity', 'isDuplicate'],
        },
      },
    });

    if (response.text) {
      const data = JSON.parse(response.text.trim());
      return {
        maxSimilarity: data.maxSimilarity,
        referencePostId: data.referenceOpportunity || data.maxSimilarity > 35 ? data.mostSimilarPostId : undefined,
        referencePostTitle: data.referenceOpportunity || data.maxSimilarity > 35 ? data.mostSimilarPostTitle : undefined,
        duplicateReason: data.isDuplicate ? (data.duplicateReason || 'Topic is semantically identical to a previously published post in memory.') : undefined,
      };
    }
  } catch (e) {
    console.error('Gemini checkMemoryContinuity error:', e);
  }

  return { maxSimilarity: 0 };
}

// 4. Generate Full Post Content & Detailed Rationale
export async function generatePostAndRationale(
  candidate: CandidateTopic,
  allCandidatesEvaluatedInCycle: CandidateTopic[],
  referencePostTitle?: string
): Promise<{
  title: string;
  headline: string;
  explanation: string;
  technicalInsights: string;
  personaOpinion: string;
  futureImplications: string;
  conclusion: string;
  fullContent: string;
  wordCount: number;
  rationale: PublishingRationale;
}> {
  try {
    const ai = getAi();
    const systemInstruction = `You are TechPulse AI, an autonomous AI Research and Emerging Technology Analyst specializing in Machine Learning, Robotics, Edge AI, Open Source AI, AI Hardware, and AI Security.
Your editorial voice:
- Professional, concise, evidence-based technical insights.
- Supports open-source innovation.
- Prefers compact/efficient AI models over unnecessarily huge ones.
- Avoids hype, marketing buzzwords, and clickbait.
- Target word count for the post: strictly between 120 and 220 words total.

Required post structure:
1. headline: Catchy technical headline (e.g., "FlashAttention-3: Harnessing Asynchronous Tensor Cores for Hopper GPUs").
2. explanation: 2-3 sentences explaining the technology or breakthrough clearly.
3. technicalInsights: Deep technical mechanism or architectural detail (e.g. CUDA kernel fusion, quantized ternary weights).
4. personaOpinion: Your stable editorial stance (why open source/efficiency matters here).
5. futureImplications: How this impacts real-world AI deployment over the next 12-24 months.
6. conclusion: A concise, thought-provoking technical takeaway.

Also generate a comprehensive "rationale" object:
- whySelected: Detailed explanation of why this topic stood out during research.
- whyRelevantNow: Why this breakthrough or update is timely and critical today.
- comparedToCandidates: Explanation of why this topic was chosen over the other candidate topics evaluated in this cycle.
- personaAlignment: How it upholds TechPulse AI's principles of open science, empirical validation, and model efficiency.
`;

    const otherCandidatesSummary = allCandidatesEvaluatedInCycle
      .filter(c => c.id !== candidate.id)
      .map(c => `"${c.title}" (Score: ${c.totalScore})`)
      .join(', ');

    const prompt = `Topic to write about:
Title: "${candidate.title}"
Summary: "${candidate.summary}"
Source: "${candidate.sourceName}" (${candidate.sourceUrl})
Category: "${candidate.category}"
${referencePostTitle ? `Note: Naturally reference our previous publication on "${referencePostTitle}" to create feed continuity.` : ''}

Other candidates evaluated in this cycle: [${otherCandidatesSummary || 'None'}]
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            headline: { type: Type.STRING },
            explanation: { type: Type.STRING },
            technicalInsights: { type: Type.STRING },
            personaOpinion: { type: Type.STRING },
            futureImplications: { type: Type.STRING },
            conclusion: { type: Type.STRING },
            rationale: {
              type: Type.OBJECT,
              properties: {
                whySelected: { type: Type.STRING },
                whyRelevantNow: { type: Type.STRING },
                comparedToCandidates: { type: Type.STRING },
                personaAlignment: { type: Type.STRING },
              },
              required: ['whySelected', 'whyRelevantNow', 'comparedToCandidates', 'personaAlignment'],
            },
          },
          required: [
            'title', 'headline', 'explanation', 'technicalInsights',
            'personaOpinion', 'futureImplications', 'conclusion', 'rationale'
          ],
        },
      },
    });

    if (response.text) {
      const data = JSON.parse(response.text.trim());
      const fullContent = `${data.headline}\n\n${data.explanation}\n\nTechnical Insights:\n${data.technicalInsights}\n\nTechPulse AI Opinion:\n${data.personaOpinion}\n\nFuture Implications:\n${data.futureImplications}\n\nConclusion:\n${data.conclusion}`;
      const wordCount = fullContent.split(/\s+/).filter(Boolean).length;

      return {
        title: data.title || candidate.title,
        headline: data.headline,
        explanation: data.explanation,
        technicalInsights: data.technicalInsights,
        personaOpinion: data.personaOpinion,
        futureImplications: data.futureImplications,
        conclusion: data.conclusion,
        fullContent,
        wordCount,
        rationale: {
          whySelected: data.rationale.whySelected,
          whyRelevantNow: data.rationale.whyRelevantNow,
          comparedToCandidates: data.rationale.comparedToCandidates,
          personaAlignment: data.rationale.personaAlignment,
          trustedSources: [
            {
              title: candidate.title,
              url: candidate.sourceUrl,
              sourceName: candidate.sourceName,
              publishedAt: candidate.discoveredAt,
            },
          ],
        },
      };
    }
  } catch (e) {
    console.error('Gemini generatePostAndRationale error:', e);
  }

  // Robust fallback content generator
  const headline = `Analysis: ${candidate.title}`;
  const explanation = candidate.summary;
  const technicalInsights = `This development highlights key advancements in ${candidate.category}. The implementation demonstrates optimized compute density and memory access efficiency over legacy baselines.`;
  const personaOpinion = `TechPulse AI strongly advocates for transparent, open-weight architectures and efficient model designs that lower memory footprints for edge deployment.`;
  const futureImplications = `Expect accelerated downstream adoption in production pipelines, driving lower inferencing latency and reduced hardware operational overhead.`;
  const conclusion = `Practical, open engineering advancements like this remain the true driver of scalable machine intelligence.`;
  const fullContent = `${headline}\n\n${explanation}\n\n${technicalInsights}\n\n${personaOpinion}\n\n${futureImplications}\n\n${conclusion}`;

  return {
    title: candidate.title,
    headline,
    explanation,
    technicalInsights,
    personaOpinion,
    futureImplications,
    conclusion,
    fullContent,
    wordCount: fullContent.split(/\s+/).filter(Boolean).length,
    rationale: {
      whySelected: `High technical score (${candidate.totalScore}/100) and strong empirical data from ${candidate.sourceName}.`,
      whyRelevantNow: `Addresses current engineering bottlenecks in ${candidate.category}.`,
      comparedToCandidates: `Outscored competing candidates in innovation and open-source persona alignment.`,
      personaAlignment: `Directly aligns with TechPulse AI principles supporting open weights and efficient compute.`,
      trustedSources: [
        {
          title: candidate.title,
          url: candidate.sourceUrl,
          sourceName: candidate.sourceName,
          publishedAt: candidate.discoveredAt,
        },
      ],
    },
  };
}
