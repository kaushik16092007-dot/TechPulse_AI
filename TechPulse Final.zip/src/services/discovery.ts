import Parser from 'rss-parser';
import { CandidateTopic } from '../types.js';

const parser = new Parser();

export interface RawDiscoveredItem {
  title: string;
  summary: string;
  sourceName: string;
  sourceUrl: string;
  category: string;
  publishedAt?: string;
}

export async function fetchLiveTopics(): Promise<RawDiscoveredItem[]> {
  const items: RawDiscoveredItem[] = [];

  // 1. Fetch Hugging Face Daily Papers
  try {
    const hfRes = await fetch('https://huggingface.co/api/daily_papers', {
      headers: { 'User-Agent': 'TechPulse-AI-Agent/1.0' },
    });
    if (hfRes.ok) {
      const papers = await hfRes.json();
      if (Array.isArray(papers)) {
        for (const p of papers.slice(0, 8)) {
          const title = p.paper?.title || p.title;
          const summary = p.paper?.summary || p.summary || p.paper?.abstract || 'New research paper published on Hugging Face';
          const id = p.paper?.id || p.id;
          if (title && id) {
            items.push({
              title: title.trim(),
              summary: summary.trim().substring(0, 300),
              sourceName: 'Hugging Face Papers',
              sourceUrl: `https://huggingface.co/papers/${id}`,
              category: determineCategory(title + ' ' + summary),
              publishedAt: p.publishedAt || new Date().toISOString(),
            });
          }
        }
      }
    }
  } catch (e) {
    console.warn('Discovery: Failed to fetch Hugging Face papers:', e);
  }

  // 2. Fetch Hacker News AI/Tech stories
  try {
    const hnTopRes = await fetch('https://hacker-news.firebaseio.com/v0/topstories.json');
    if (hnTopRes.ok) {
      const topIds: number[] = await hnTopRes.json();
      const selectedIds = topIds.slice(0, 20);

      const storyPromises = selectedIds.map(id =>
        fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`).then(r => r.json())
      );
      const stories = await Promise.all(storyPromises);

      for (const story of stories) {
        if (!story || !story.title || !story.url) continue;
        const lowerTitle = story.title.toLowerCase();
        const isAiTech =
          lowerTitle.includes('ai') ||
          lowerTitle.includes('llm') ||
          lowerTitle.includes('model') ||
          lowerTitle.includes('gpu') ||
          lowerTitle.includes('robot') ||
          lowerTitle.includes('open source') ||
          lowerTitle.includes('transformer') ||
          lowerTitle.includes('agent') ||
          lowerTitle.includes('neural') ||
          lowerTitle.includes('vision') ||
          lowerTitle.includes('security') ||
          lowerTitle.includes('quantum');

        if (isAiTech) {
          items.push({
            title: story.title,
            summary: `Hacker News discussion with ${story.score || 0} points and ${story.descendants || 0} comments regarding technical advancements and community findings.`,
            sourceName: 'Hacker News',
            sourceUrl: story.url || `https://news.ycombinator.com/item?id=${story.id}`,
            category: determineCategory(story.title),
            publishedAt: new Date((story.time || Date.now() / 1000) * 1000).toISOString(),
          });
        }
      }
    }
  } catch (e) {
    console.warn('Discovery: Failed to fetch Hacker News stories:', e);
  }

  // 3. Fetch ArXiv CS.AI / CS.LG RSS feed
  try {
    const arxivFeed = await parser.parseURL('https://export.arxiv.org/rss/cs.AI');
    if (arxivFeed.items && arxivFeed.items.length > 0) {
      for (const item of arxivFeed.items.slice(0, 6)) {
        if (item.title && item.link) {
          items.push({
            title: item.title.replace(/\n/g, ' ').replace(/\(arXiv:.*\)/, '').trim(),
            summary: (item.contentSnippet || item.summary || 'ArXiv pre-print research paper').substring(0, 300),
            sourceName: 'ArXiv CS.AI',
            sourceUrl: item.link,
            category: determineCategory(item.title + ' ' + (item.contentSnippet || '')),
            publishedAt: item.pubDate || new Date().toISOString(),
          });
        }
      }
    }
  } catch (e) {
    console.warn('Discovery: Failed to fetch ArXiv RSS feed:', e);
  }

  return items;
}

export function determineCategory(text: string): string {
  const t = text.toLowerCase();
  if (t.includes('robot') || t.includes('autonomous') || t.includes('drone') || t.includes('manipulation') || t.includes('humanoid')) {
    return 'Robotics';
  }
  if (t.includes('edge') || t.includes('embedded') || t.includes('mobile') || t.includes('microcontroller') || t.includes('quantiz')) {
    return 'Edge AI';
  }
  if (t.includes('open source') || t.includes('github') || t.includes('hf') || t.includes('llama') || t.includes('mistral') || t.includes('weights')) {
    return 'Open Source AI';
  }
  if (t.includes('gpu') || t.includes('tpu') || t.includes('chip') || t.includes('hardware') || t.includes('semiconductor') || t.includes('wafer') || t.includes('memory bandwidth')) {
    return 'AI Hardware';
  }
  if (t.includes('security') || t.includes('jailbreak') || t.includes('privacy') || t.includes('alignment') || t.includes('adversarial') || t.includes('watermark')) {
    return 'AI Security';
  }
  return 'Machine Learning';
}
