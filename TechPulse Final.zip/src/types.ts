export interface CriteriaScores {
  recency: number;           // 0-100
  innovation: number;        // 0-100
  engineeringValue: number;  // 0-100
  educationalValue: number;  // 0-100
  sourceCredibility: number; // 0-100
  novelty: number;           // 0-100
  communityInterest: number; // 0-100
  personaAlignment: number;  // 0-100
}

export type TopicStatus = 'pending' | 'published' | 'rejected';

export interface CandidateTopic {
  id: string;
  title: string;
  summary: string;
  sourceName: string;
  sourceUrl: string;
  discoveredAt: string; // ISO string
  category: string;     // ML, Robotics, Edge AI, Open Source AI, AI Hardware, AI Security
  criteriaScores: CriteriaScores;
  totalScore: number;   // 0-100 weighted average
  status: TopicStatus;
  rejectionReason?: string;
  semanticSimilarityScore?: number;
}

export interface TrustedSource {
  title: string;
  url: string;
  sourceName: string;
  publishedAt?: string;
}

export interface PublishingRationale {
  whySelected: string;
  whyRelevantNow: string;
  comparedToCandidates: string;
  personaAlignment: string;
  trustedSources: TrustedSource[];
}

export interface PublishedPost {
  id: string;
  agentId: string;
  timestamp: string; // ISO string (UTC)
  title: string;
  headline: string;
  explanation: string;
  technicalInsights: string;
  personaOpinion: string;
  futureImplications: string;
  conclusion: string;
  fullContent: string;
  rationale: PublishingRationale;
  sources: TrustedSource[];
  category: string;
  wordCount: number;
  referencesPreviousPostId?: string;
  referencesPreviousPostTitle?: string;
}

export type AgentStatus = 'idle' | 'researching' | 'scoring' | 'publishing' | 'sleeping';

export interface AgentState {
  agentId: string;
  name: string;
  personaTitle: string;
  status: AgentStatus;
  initializedAt: string;
  lastRunAt: string | null;
  nextRunAt: string | null;
  intervalMinutes: number;
  minScoreThreshold: number;
  totalRunsCount: number;
  totalPostsPublished: number;
  totalTopicsRejected: number;
  currentDomainFocus: string;
}

export interface AgentConfig {
  intervalMinutes: number;
  minScoreThreshold: number;
  autoRunEnabled: boolean;
  domainFocuses: string[];
}

export interface MemoryNode {
  id: string;
  topicSummary: string;
  category: string;
  keywords: string[];
  timestamp: string;
  publishedPostId: string;
  headline: string;
}

export interface LogEntry {
  id: string;
  agentId: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  action: string;
  message: string;
  details?: any;
}

export interface InitAgentResponse {
  success: boolean;
  agentId: string;
  status: string;
  message: string;
  initializedAt: string;
  config: AgentConfig;
}

export interface FeedResponse {
  agentId: string;
  count: number;
  posts: PublishedPost[];
}
