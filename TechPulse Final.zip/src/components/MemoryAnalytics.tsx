import React from 'react';
import { MemoryNode, PublishedPost } from '../types';
import { Layers, Database, GitBranch, Cpu, ShieldCheck, Sparkles } from 'lucide-react';

interface MemoryAnalyticsProps {
  memoryNodes: MemoryNode[];
  posts: PublishedPost[];
}

export const MemoryAnalytics: React.FC<MemoryAnalyticsProps> = ({ memoryNodes, posts }) => {
  // Category counts
  const categories = ['Machine Learning', 'Robotics', 'Edge AI', 'Open Source AI', 'AI Hardware', 'AI Security'];
  const categoryCounts: Record<string, number> = {};
  categories.forEach(c => (categoryCounts[c] = 0));

  posts.forEach(p => {
    if (categoryCounts[p.category] !== undefined) {
      categoryCounts[p.category]++;
    } else {
      categoryCounts[p.category] = 1;
    }
  });

  const totalPosts = posts.length || 1;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl border border-cyan-500/20 bg-gradient-to-r from-slate-900 via-slate-900 to-blue-950/40 p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold tracking-wider uppercase mb-1">
              <Layers className="h-4 w-4" />
              <span>SQLite Memory Engine & Continuity Graph</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-100">Long-Term Memory Engine</h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Stores past publications, keywords, and semantic embeddings in SQLite. Enables future research cycles to naturally cross-reference previous publications and avoid duplicate coverage.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-slate-400">Stored Memory Nodes</div>
              <div className="text-2xl font-bold text-cyan-400">{memoryNodes.length}</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-400">Feed Continuity Links</div>
              <div className="text-2xl font-bold text-purple-400">
                {posts.filter(p => p.referencesPreviousPostTitle).length}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Domain Distribution */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-3 flex items-center gap-2">
            <Cpu className="h-4 w-4 text-cyan-400" />
            <span>Category Knowledge Share</span>
          </h3>

          <div className="space-y-3">
            {categories.map(cat => {
              const count = categoryCounts[cat] || 0;
              const percentage = Math.round((count / totalPosts) * 100);
              return (
                <div key={cat} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-300 font-medium">{cat}</span>
                    <span className="text-slate-400 font-mono">
                      {count} posts ({percentage}%)
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-500"
                      style={{ width: `${Math.max(8, percentage)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Memory Node Timeline Graph */}
        <div className="lg:col-span-2 rounded-2xl border border-slate-800 bg-slate-900/80 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-3 flex items-center gap-2">
            <GitBranch className="h-4 w-4 text-purple-400" />
            <span>Cross-Post Semantic Continuity Timeline</span>
          </h3>

          <div className="space-y-4">
            {memoryNodes.length === 0 ? (
              <div className="text-xs text-slate-500 py-10 text-center">No memory nodes recorded yet.</div>
            ) : (
              memoryNodes.map((node, idx) => (
                <div key={node.id || idx} className="relative pl-6 border-l-2 border-cyan-500/30 pb-3">
                  <div className="absolute -left-1.5 top-0 h-3 w-3 rounded-full bg-cyan-400 ring-4 ring-slate-900" />
                  <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 mb-1">
                    <span className="font-semibold text-cyan-300 uppercase">{node.category}</span>
                    <span>{new Date(node.timestamp).toUTCString()}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-200">{node.headline}</h4>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{node.topicSummary}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
