import React, { useState } from 'react';
import { PublishedPost } from '../types';
import {
  Sparkles,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Search,
  BookOpen,
  Share2,
  Check,
  Tag,
  Clock,
  ShieldAlert,
  ArrowRight,
  Database
} from 'lucide-react';

interface FeedViewProps {
  posts: PublishedPost[];
  agentId: string;
  isLoading: boolean;
  onRefresh: () => void;
}

export const FeedView: React.FC<FeedViewProps> = ({ posts, agentId, isLoading, onRefresh }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedRationalePostId, setExpandedRationalePostId] = useState<string | null>(null);
  const [copiedPostId, setCopiedPostId] = useState<string | null>(null);

  const categories = ['All', 'Machine Learning', 'Robotics', 'Edge AI', 'Open Source AI', 'AI Hardware', 'AI Security'];

  const filteredPosts = posts.filter(post => {
    const matchesCategory = selectedCategory === 'All' || post.category === selectedCategory;
    const matchesSearch =
      post.headline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.explanation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleCopyPostJson = (post: PublishedPost) => {
    navigator.clipboard.writeText(JSON.stringify(post, null, 2));
    setCopiedPostId(post.id);
    setTimeout(() => setCopiedPostId(null), 2000);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Edge AI':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'Robotics':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      case 'Open Source AI':
        return 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30';
      case 'AI Hardware':
        return 'bg-purple-500/15 text-purple-400 border-purple-500/30';
      case 'AI Security':
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
      case 'Machine Learning':
      default:
        return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner / Header */}
      <div className="rounded-2xl border border-cyan-500/20 bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold tracking-wider uppercase mb-1">
              <Sparkles className="h-4 w-4 text-cyan-400" />
              <span>Autonomous Editorial Feed</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-100">TechPulse AI Research Log</h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Continuously discovered, evaluated, and published without human intervention. Every post adheres to empirical rigor and transparent editorial rationale.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <div className="text-xs text-slate-400">Total Autonomous Posts</div>
              <div className="text-2xl font-bold text-cyan-400">{posts.length}</div>
            </div>
            <button
              onClick={onRefresh}
              className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-all"
            >
              <span>Refresh Feed</span>
            </button>
          </div>
        </div>

        {/* Filters & Search Bar */}
        <div className="mt-6 flex flex-col md:flex-row items-center gap-4 pt-4 border-t border-slate-800/80">
          <div className="relative w-full md:w-72">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search published posts..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto overflow-x-auto">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                  selectedCategory === cat
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                    : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Feed List */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-16 space-y-4">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-500 border-t-transparent"></div>
          <p className="text-xs text-slate-400">Fetching TechPulse AI feed...</p>
        </div>
      ) : filteredPosts.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/30 p-12 text-center">
          <BookOpen className="mx-auto h-10 w-10 text-slate-600 mb-3" />
          <h3 className="text-base font-semibold text-slate-300">No Posts Found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            No published posts matched your search criteria. Try selecting another category or run an autonomous research cycle.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredPosts.map(post => {
            const isRationaleExpanded = expandedRationalePostId === post.id;
            return (
              <article
                key={post.id}
                className="group relative rounded-2xl border border-slate-800/80 bg-slate-900/70 p-6 shadow-lg transition-all hover:border-slate-700/80 hover:bg-slate-900/90"
              >
                {/* Post Top Metadata */}
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2">
                    <span className={`rounded-full border px-3 py-0.5 text-xs font-semibold ${getCategoryColor(post.category)}`}>
                      {post.category}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] text-slate-400">
                      <Clock className="h-3 w-3 text-slate-500" />
                      <span>{new Date(post.timestamp).toUTCString()}</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[11px] text-slate-500 font-mono">
                      {post.wordCount} words • ~{Math.max(1, Math.ceil(post.wordCount / 180))} min read
                    </span>
                    <button
                      onClick={() => handleCopyPostJson(post)}
                      className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition-all"
                      title="Copy JSON Payload"
                    >
                      {copiedPostId === post.id ? (
                        <Check className="h-3.5 w-3.5 text-emerald-400" />
                      ) : (
                        <Share2 className="h-3.5 w-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Headline */}
                <h3 className="text-xl font-bold text-slate-100 group-hover:text-cyan-300 transition-colors leading-snug">
                  {post.headline}
                </h3>

                {/* Main Post Sections */}
                <div className="mt-4 space-y-4 text-xs text-slate-300 leading-relaxed">
                  {/* Explanation */}
                  <p className="text-sm font-normal text-slate-200 leading-relaxed">{post.explanation}</p>

                  {/* Technical Insights */}
                  {post.technicalInsights && (
                    <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                      <div className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider mb-1">
                        Technical Insights
                      </div>
                      <p className="text-slate-300">{post.technicalInsights}</p>
                    </div>
                  )}

                  {/* Persona Opinion */}
                  {post.personaOpinion && (
                    <div className="rounded-xl border border-cyan-500/20 bg-cyan-950/20 p-4">
                      <div className="text-[11px] font-semibold text-cyan-300 uppercase tracking-wider mb-1">
                        TechPulse AI Editorial Stance
                      </div>
                      <p className="text-slate-200 italic">"{post.personaOpinion}"</p>
                    </div>
                  )}

                  {/* Future Implications & Conclusion */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {post.futureImplications && (
                      <div className="rounded-xl border border-slate-800/80 bg-slate-950/40 p-3.5">
                        <div className="text-[11px] font-semibold text-purple-400 uppercase tracking-wider mb-1">
                          Future Implications
                        </div>
                        <p className="text-slate-300">{post.futureImplications}</p>
                      </div>
                    )}
                    {post.conclusion && (
                      <div className="rounded-xl border border-slate-800/80 bg-slate-950/40 p-3.5">
                        <div className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider mb-1">
                          Key Takeaway
                        </div>
                        <p className="text-slate-300">{post.conclusion}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Memory Continuity Reference */}
                {post.referencesPreviousPostTitle && (
                  <div className="mt-4 flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-950/80 px-3 py-2 text-xs text-slate-400">
                    <Database className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
                    <span>Memory Continuity: Builds upon earlier analysis of </span>
                    <span className="font-medium text-cyan-300 italic">"{post.referencesPreviousPostTitle}"</span>
                  </div>
                )}

                {/* Editorial Rationale Toggle Bar */}
                <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <button
                    onClick={() =>
                      setExpandedRationalePostId(isRationaleExpanded ? null : post.id)
                    }
                    className="flex items-center gap-2 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
                  >
                    <ShieldAlert className="h-4 w-4" />
                    <span>
                      {isRationaleExpanded ? 'Hide Editorial Rationale' : 'Inspect Publishing Rationale'}
                    </span>
                    {isRationaleExpanded ? (
                      <ChevronUp className="h-3.5 w-3.5" />
                    ) : (
                      <ChevronDown className="h-3.5 w-3.5" />
                    )}
                  </button>

                  {/* Sources Preview */}
                  {post.sources && post.sources.length > 0 && (
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span className="text-[11px] text-slate-500">Source:</span>
                      <a
                        href={post.sources[0].url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 font-medium text-cyan-400 hover:underline"
                      >
                        <span>{post.sources[0].sourceName || 'Primary Research Source'}</span>
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  )}
                </div>

                {/* Expandable Editorial Rationale Card */}
                {isRationaleExpanded && post.rationale && (
                  <div className="mt-4 rounded-xl border border-cyan-500/30 bg-slate-950/90 p-5 space-y-3 text-xs text-slate-300 shadow-inner">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <h4 className="font-bold text-cyan-300 uppercase tracking-wider text-[11px] flex items-center gap-2">
                        <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
                        <span>Autonomous Editorial Decision Rationale</span>
                      </h4>
                      <span className="text-[10px] text-slate-500 font-mono">Agent ID: {post.agentId}</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <div className="text-slate-400 font-semibold mb-1">Why Selected:</div>
                        <p className="text-slate-200">{post.rationale.whySelected}</p>
                      </div>

                      <div>
                        <div className="text-slate-400 font-semibold mb-1">Why Relevant Now:</div>
                        <p className="text-slate-200">{post.rationale.whyRelevantNow}</p>
                      </div>

                      <div>
                        <div className="text-slate-400 font-semibold mb-1">Candidate Comparison:</div>
                        <p className="text-slate-200">{post.rationale.comparedToCandidates}</p>
                      </div>

                      <div>
                        <div className="text-slate-400 font-semibold mb-1">Persona Alignment:</div>
                        <p className="text-slate-200">{post.rationale.personaAlignment}</p>
                      </div>
                    </div>

                    {/* Sources Detail */}
                    {post.sources && post.sources.length > 0 && (
                      <div className="pt-2 border-t border-slate-800/80">
                        <div className="text-slate-400 font-semibold mb-1">Trusted Primary Sources:</div>
                        <div className="flex flex-wrap gap-2">
                          {post.sources.map((src, idx) => (
                            <a
                              key={idx}
                              href={src.url}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1 text-[11px] text-cyan-400 hover:border-cyan-500/50"
                            >
                              <span>{src.title}</span>
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
