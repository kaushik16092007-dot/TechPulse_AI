import React, { useState, useEffect } from 'react';
import { AgentState, LogEntry } from '../types';
import {
  Activity,
  Play,
  RefreshCw,
  Clock,
  ShieldCheck,
  Zap,
  Sliders,
  Terminal,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Cpu,
  Layers,
  Database
} from 'lucide-react';

interface AgentControlProps {
  agentState: AgentState | null;
  logs: LogEntry[];
  onTriggerCycle: () => void;
  onInitAgent: (customId?: string, interval?: number, threshold?: number) => void;
  onUpdateConfig: (interval: number, threshold: number) => void;
  isTriggering: boolean;
}

export const AgentControl: React.FC<AgentControlProps> = ({
  agentState,
  logs,
  onTriggerCycle,
  onInitAgent,
  onUpdateConfig,
  isTriggering,
}) => {
  const [customAgentId, setCustomAgentId] = useState('');
  const [intervalMinutes, setIntervalMinutes] = useState(agentState?.intervalMinutes || 30);
  const [minThreshold, setMinThreshold] = useState(agentState?.minScoreThreshold || 75);
  const [secondsUntilNext, setSecondsUntilNext] = useState<number>(0);

  useEffect(() => {
    if (agentState) {
      setIntervalMinutes(agentState.intervalMinutes);
      setMinThreshold(agentState.minScoreThreshold);
    }
  }, [agentState]);

  // Countdown timer calculation
  useEffect(() => {
    if (!agentState?.nextRunAt) return;

    const updateTimer = () => {
      const nextTime = new Date(agentState.nextRunAt!).getTime();
      const now = Date.now();
      const diff = Math.max(0, Math.floor((nextTime - now) / 1000));
      setSecondsUntilNext(diff);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [agentState?.nextRunAt]);

  const formatCountdown = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl border border-cyan-500/20 bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold tracking-wider uppercase mb-1">
              <Activity className="h-4 w-4" />
              <span>Autonomous Background Engine & Scheduler</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-100">TechPulse AI Control Center</h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Configured to operate as an independent AI employee. Executes autonomous research cycles, scores candidates against 8 editorial criteria, and updates memory graph.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onTriggerCycle}
              disabled={isTriggering}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 px-5 py-2.5 text-xs font-bold text-slate-950 shadow-lg shadow-cyan-500/25 transition-all hover:scale-105 disabled:opacity-50"
            >
              {isTriggering ? (
                <RefreshCw className="h-4 w-4 animate-spin text-slate-950" />
              ) : (
                <Play className="h-4 w-4 fill-slate-950 text-slate-950" />
              )}
              <span>{isTriggering ? 'Executing Autonomous Cycle...' : 'Run Autonomous Cycle Now'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Agent Persona State */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Agent Status</span>
            <Cpu className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
            </span>
            <span className="text-lg font-bold text-slate-100 capitalize">{agentState?.status || 'Active'}</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 font-mono">
            ID: {agentState?.agentId || 'agent_techpulse_default'}
          </div>
        </div>

        {/* Card 2: Scheduler Timer */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Next Scheduled Cycle</span>
            <Clock className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-cyan-400">
            {formatCountdown(secondsUntilNext)}
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Every {agentState?.intervalMinutes || 30} minutes
          </div>
        </div>

        {/* Card 3: Total Runs & Publications */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Published / Total Runs</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-slate-100">
            {agentState?.totalPostsPublished || 0} <span className="text-sm font-normal text-slate-500">/ {agentState?.totalRunsCount || 0} cycles</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Published topics met threshold
          </div>
        </div>

        {/* Card 4: Rejected Topics */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Rejected Topics</span>
            <ShieldCheck className="h-4 w-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-purple-400">
            {agentState?.totalTopicsRejected || 0}
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Filtered out by editorial rules
          </div>
        </div>
      </div>

      {/* Initialization & Parameters Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* POST /api/agent/init Controls */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6 space-y-4">
          <div className="flex items-center gap-2 text-cyan-400 text-sm font-bold border-b border-slate-800 pb-3">
            <Zap className="h-4 w-4" />
            <span>Initialize Persona (POST /api/agent/init)</span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Initialize or reset the TechPulse AI agent persona. Initializes background worker memory, registers initial agent ID, and seeds baseline topics.
          </p>

          <div className="space-y-3">
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">Custom Agent ID (Optional)</label>
              <input
                type="text"
                placeholder="e.g. agent_techpulse_hackathon_2026"
                value={customAgentId}
                onChange={e => setCustomAgentId(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => onInitAgent(customAgentId || undefined, intervalMinutes, minThreshold)}
                className="flex items-center gap-2 rounded-xl border border-cyan-500/40 bg-cyan-950/60 px-4 py-2 text-xs font-bold text-cyan-300 hover:bg-cyan-900/60 transition-all"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Initialize Agent Now</span>
              </button>
            </div>
          </div>
        </div>

        {/* Configuration Sliders */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6 space-y-4">
          <div className="flex items-center gap-2 text-purple-400 text-sm font-bold border-b border-slate-800 pb-3">
            <Sliders className="h-4 w-4" />
            <span>Autonomous Parameters & Thresholds</span>
          </div>

          <div className="space-y-4">
            {/* Cycle Interval Slider */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Cycle Interval (Minutes)</span>
                <span className="text-cyan-400 font-mono font-bold">{intervalMinutes} mins</span>
              </div>
              <input
                type="range"
                min="5"
                max="60"
                step="5"
                value={intervalMinutes}
                onChange={e => setIntervalMinutes(Number(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>5 mins (Fast Demo)</span>
                <span>30 mins (Default)</span>
                <span>60 mins</span>
              </div>
            </div>

            {/* Minimum Editorial Score Threshold Slider */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Editorial Publishing Threshold</span>
                <span className="text-purple-400 font-mono font-bold">{minThreshold} / 100</span>
              </div>
              <input
                type="range"
                min="50"
                max="90"
                step="5"
                value={minThreshold}
                onChange={e => setMinThreshold(Number(e.target.value))}
                className="w-full accent-purple-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>50 (Permissive)</span>
                <span>75 (Strict TechPulse Standard)</span>
                <span>90 (Ultra Strict)</span>
              </div>
            </div>

            <button
              onClick={() => onUpdateConfig(intervalMinutes, minThreshold)}
              className="w-full rounded-xl bg-slate-800 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700 transition-all border border-slate-700"
            >
              Save Configuration Settings
            </button>
          </div>
        </div>
      </div>

      {/* Live System Audit Terminal Log */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Terminal className="h-4 w-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-slate-200">Autonomous Cycle Audit Trail Logs</h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">{logs.length} entries</span>
        </div>

        <div className="font-mono text-[11px] space-y-2 max-h-80 overflow-y-auto pr-2 no-scrollbar">
          {logs.length === 0 ? (
            <div className="text-slate-600 py-6 text-center">No audit logs available. Trigger a cycle to see real-time agent output.</div>
          ) : (
            logs.map((log, idx) => (
              <div key={log.id || idx} className="flex items-start gap-3 border-b border-slate-900 pb-1.5">
                <span className="text-slate-500 shrink-0">{new Date(log.timestamp).toLocaleTimeString()}</span>
                <span
                  className={`px-1.5 py-0.2 rounded text-[10px] font-bold shrink-0 uppercase ${
                    log.level === 'success'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : log.level === 'warn'
                      ? 'bg-amber-950 text-amber-400 border border-amber-800'
                      : log.level === 'error'
                      ? 'bg-rose-950 text-rose-400 border border-rose-800'
                      : 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                  }`}
                >
                  {log.action}
                </span>
                <span className="text-slate-300 break-all">{log.message}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
