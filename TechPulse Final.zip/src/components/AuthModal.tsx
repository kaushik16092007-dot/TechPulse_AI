import React, { useState, useEffect } from 'react';
import { getSupabaseClient } from '../lib/supabase';
import { signInWithGoogle, logOutFirebase, auth as firebaseAuth } from '../lib/firebase';
import { User as SupabaseUser } from '@supabase/supabase-js';
import { User as FirebaseUser } from 'firebase/auth';
import { Shield, Key, Mail, Lock, LogOut, CheckCircle, AlertCircle, X, Flame } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: SupabaseUser | null;
  onUserChange: (user: SupabaseUser | null) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, user, onUserChange }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [fbUser, setFbUser] = useState<FirebaseUser | null>(null);

  const supabase = getSupabaseClient();

  useEffect(() => {
    const unsubscribe = firebaseAuth.onAuthStateChanged((currentUser) => {
      setFbUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!supabase) return;

    supabase.auth.getSession().then(({ data: { session } }) => {
      onUserChange(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      onUserChange(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, [supabase, onUserChange]);

  if (!isOpen) return null;

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabase) {
      setErrorMsg('Supabase is not configured. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment variables.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      if (isSignUp) {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        setSuccessMsg('Account registered! Please check your email for confirmation or sign in.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setSuccessMsg('Successfully signed in!');
        setTimeout(() => onClose(), 1000);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      await signInWithGoogle();
      setSuccessMsg('Signed in with Google via Firebase!');
    } catch (err: any) {
      setErrorMsg(err.message || 'Google Sign-In failed');
    } finally {
      setLoading(false);
    }
  };

  const handleFirebaseSignOut = async () => {
    setLoading(true);
    await logOutFirebase();
    setLoading(false);
    setSuccessMsg('Signed out of Firebase.');
  };

  const handleSignOut = async () => {
    if (!supabase) return;
    setLoading(true);
    await supabase.auth.signOut();
    onUserChange(null);
    setLoading(false);
    setSuccessMsg('Signed out successfully.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-md rounded-2xl border border-slate-800 bg-[#0D1117] p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-slate-100 transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-cyan-500/30 bg-cyan-950/40 text-cyan-400">
            <Shield className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">Identity & Persistence Control</h3>
            <p className="text-xs text-slate-400">Firebase Firestore & Supabase Access</p>
          </div>
        </div>

        {/* Firebase Live Backend Banner */}
        <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-3 space-y-1.5">
          <div className="flex items-center justify-between text-xs font-bold text-amber-400">
            <span className="flex items-center gap-1.5">
              <Flame className="h-4 w-4 text-amber-400" />
              Firebase Firestore Active
            </span>
            <span className="font-mono text-[10px] bg-amber-500/20 px-2 py-0.5 rounded text-amber-300">
              astral-lens-x9v0l
            </span>
          </div>
          <p className="text-[11px] text-slate-300">
            Cloud database provisioned in region <code className="text-amber-300">asia-southeast1</code> with secure ABAC rules.
          </p>

          {fbUser ? (
            <div className="mt-2 flex items-center justify-between bg-slate-900/80 p-2 rounded-lg border border-slate-800 text-xs">
              <div className="truncate">
                <span className="text-emerald-400 font-semibold">Google User: </span>
                <span className="text-slate-300">{fbUser.email}</span>
              </div>
              <button
                onClick={handleFirebaseSignOut}
                className="text-[10px] text-slate-400 hover:text-rose-400 underline ml-2"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <button
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="mt-2 w-full flex items-center justify-center gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 py-1.5 text-xs font-semibold text-amber-300 hover:bg-amber-500/20 transition-all disabled:opacity-50"
            >
              <Flame className="h-3.5 w-3.5" />
              <span>Sign In with Google (Firebase)</span>
            </button>
          )}
        </div>

        {/* Supabase Section */}
        {!supabase ? (
          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
              <AlertCircle className="h-4 w-4" />
              <span>Supabase Auth Optional</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Firebase Firestore is fully active as primary persistence. Optional Supabase credentials can be added via environment settings.
            </p>
          </div>
        ) : user ? (
          <div className="space-y-4">
            <div className="rounded-xl border border-emerald-500/30 bg-emerald-950/20 p-4 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                <CheckCircle className="h-4 w-4" />
                <span>Supabase User Authenticated</span>
              </div>
              <p className="text-xs text-slate-200 font-mono break-all">{user.email}</p>
              <p className="text-[10px] text-slate-400">UID: {user.id}</p>
            </div>

            <button
              onClick={handleSignOut}
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800 py-2.5 text-xs font-bold text-slate-200 hover:bg-slate-700 transition-all"
            >
              <LogOut className="h-4 w-4" />
              <span>Sign Out Supabase</span>
            </button>
          </div>
        ) : (
          <form onSubmit={handleAuth} className="space-y-3 pt-1">
            <div className="text-xs font-bold text-slate-300 flex items-center gap-2">
              <Shield className="h-3.5 w-3.5 text-cyan-400" />
              <span>Supabase Identity Login</span>
            </div>

            {errorMsg && (
              <div className="rounded-xl border border-rose-500/30 bg-rose-950/30 p-3 text-xs text-rose-300">
                {errorMsg}
              </div>
            )}
            {successMsg && (
              <div className="rounded-xl border border-emerald-500/30 bg-emerald-950/30 p-3 text-xs text-emerald-300">
                {successMsg}
              </div>
            )}

            <div>
              <label className="block text-[11px] font-medium text-slate-400 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="analyst@techpulse.ai"
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-400 mb-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 py-2.5 text-xs font-bold text-slate-950 hover:from-cyan-400 hover:to-blue-500 transition-all shadow-lg shadow-cyan-500/20 disabled:opacity-50"
            >
              <Key className="h-4 w-4" />
              <span>{loading ? 'Processing...' : isSignUp ? 'Create Supabase Account' : 'Sign In with Supabase'}</span>
            </button>

            <div className="text-center pt-1">
              <button
                type="button"
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-xs text-cyan-400 hover:underline"
              >
                {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

