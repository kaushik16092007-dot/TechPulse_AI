import React, { useState } from 'react';
import { CandidateTopic } from '../types';
import { ShieldCheck, Filter, AlertTriangle, ExternalLink, Sparkles, CheckCircle2, XCircle } from 'lucide-react';

interface EditorialRoomProps {
  candidates: CandidateTopic[];
  minThreshold: number;
}

export const EditorialRoom: React.FC<EditorialRoomProps> = ({ candidates, minThreshold }) => {
  const [filter, setFilter] = useState<'all' | 'rejected' | 'published' | 'pending'>('all');
  const [selectedCandidate, setSelectedCandidate] = useState<CandidateTopic | null>(null);

  const filteredCandidates = candidates.filter(c => {
    if (filter === 'all') return true;
    return c.status === filter;
  });

  const rejectedCount = candidates.filter(c => c.status === 'rejected').length;
  const publishedCount = candidates.filter(c => c.status === 'published').length;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl border border-purple-500/20 bg-gradient-to-r from-slate-900 via-slate-900 to-purple-950/40 p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-purple-400 text-xs font-semibold tracking-wider uppercase mb-1">
              <ShieldCheck className="h-4 w-4" />
              <span>Editorial Judgment & Filter Matrix</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-100">Editorial Decision Room</h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              TechPulse AI rejects low-quality hype, clickbait, and duplicate topics. Inspect how candidates score across 8 rigorous technical criteria before publication decisions are reached.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-slate-400">Rejected Topics</div>
              <div className="text-2xl font-bold text-rose-400">{rejectedCount}</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-400">Published Topics</div>
              <div className="text-2xl font-bold text-emerald-400">{publishedCount}</div>
            </div>
          </div>
        </div>

        {/* Filter buttons */}
        <div className="mt-6 flex flex-wrap items-center gap-2 pt-4 border-t border-slate-800">
          {[
            { id: 'all', label: `All Candidates (${candidates.length})` },
            { id: 'rejected', label: `Rejected Topics (${rejectedCount})` },
            { id: 'published', label: `Published Topics (${publishedCount})` },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id as any)}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-medium transition-all ${
                filter === f.id
                  ? 'bg-purple-500 text-slate-950 font-bold shadow-md shadow-purple-500/20'
                  : 'bg-slate-800/60 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Candidates List */}
        <div className="lg:col-span-2 space-y-3">
          {filteredCandidates.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/30 p-12 text-center text-slate-500 text-xs">
              No candidates in this view. Trigger a cycle to populate the candidate queue.
            </div>
          ) : (
            filteredCandidates.map(c => {
              const isSelected = selectedCandidate?.id === c.id;
              return (
                <div
                  key={c.id}
                  onClick={() => setSelectedCandidate(c)}
                  className={`cursor-pointer rounded-2xl border p-5 transition-all ${
                    isSelected
                      ? 'border-purple-500/60 bg-purple-950/20 shadow-lg shadow-purple-500/10'
                      : 'border-slate-800 bg-slate-900/70 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase ${
                          c.status === 'published'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : c.status === 'rejected'
                            ? 'bg-rose-950 text-rose-400 border border-rose-800'
                            : 'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}
                      >
                        {c.status}
                      </span>
                      <span className="text-xs text-slate-400">{c.category}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">Score:</span>
                      <span
                        className={`font-mono font-bold text-sm ${
                          c.totalScore >= minThreshold ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {c.totalScore} / 100
                      </span>
                    </div>
                  </div>

                  <h4 className="text-base font-bold text-slate-100 mb-1">{c.title}</h4>
                  <p className="text-xs text-slate-400 line-clamp-2">{c.summary}</p>

                  {/* Rejection Reason highlight */}
                  {c.status === 'rejected' && c.rejectionReason && (
                    <div className="mt-3 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-950/20 p-2.5 text-xs text-rose-300">
                      <XCircle className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-rose-200">Rejection Reason: </span>
                        <span>{c.rejectionReason}</span>
                      </div>
                    </div>
                  )}

                  <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Source: {c.sourceName}</span>
                    <span className="text-purple-400 font-medium">Click to inspect 8-criteria breakdown →</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: 8-Criteria Scoring Breakdown Inspector */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-6 space-y-5 h-fit sticky top-20">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-3 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-purple-400" />
            <span>8-Criteria Score Matrix</span>
          </h3>

          {!selectedCandidate ? (
            <div className="text-xs text-slate-500 py-10 text-center">
              Select any candidate on the left to inspect its multi-dimensional scoring breakdown and editorial analysis.
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <div className="text-xs font-bold text-slate-100">{selectedCandidate.title}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{selectedCandidate.sourceName}</div>
              </div>

              {/* Status Badge */}
              <div className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950 p-3">
                <span className="text-xs text-slate-400">Total Weighted Score</span>
                <span
                  className={`text-lg font-mono font-bold ${
                    selectedCandidate.totalScore >= minThreshold ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {selectedCandidate.totalScore} / 100
                </span>
              </div>

              {/* 8 Criteria Sliders */}
              <div className="space-y-2.5">
                {[
                  { label: 'Recency & Timeliness', value: selectedCandidate.criteriaScores?.recency },
                  { label: 'Architectural Innovation', value: selectedCandidate.criteriaScores?.innovation },
                  { label: 'Engineering Value', value: selectedCandidate.criteriaScores?.engineeringValue },
                  { label: 'Educational Depth', value: selectedCandidate.criteriaScores?.educationalValue },
                  { label: 'Source Credibility', value: selectedCandidate.criteriaScores?.sourceCredibility },
                  { label: 'Topic Novelty', value: selectedCandidate.criteriaScores?.novelty },
                  { label: 'Community Interest', value: selectedCandidate.criteriaScores?.communityInterest },
                  { label: 'Persona Alignment', value: selectedCandidate.criteriaScores?.personaAlignment },
                ].map((crit, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-400">{crit.label}</span>
                      <span className="text-slate-200 font-mono font-bold">{crit.value || 0}</span>
                    </div>
                    <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-purple-500 to-cyan-400"
                        style={{ width: `${crit.value || 0}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* Source Link */}
              <a
                href={selectedCandidate.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-800 bg-slate-950 py-2 text-xs font-semibold text-cyan-400 hover:bg-slate-800 transition-all"
              >
                <span>View Original Source</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
