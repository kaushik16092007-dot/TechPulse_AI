import React, { useState } from 'react';
import { Terminal, Copy, Check, Play, Send, Code, Sparkles } from 'lucide-react';

interface ApiExplorerProps {
  agentId: string;
}

export const ApiExplorer: React.FC<ApiExplorerProps> = ({ agentId }) => {
  const [activeEndpoint, setActiveEndpoint] = useState<'init' | 'feed' | 'status' | 'trigger'>('init');
  const [initAgentIdInput, setInitAgentIdInput] = useState(agentId || 'agent_techpulse_demo');
  const [feedAgentIdInput, setFeedAgentIdInput] = useState(agentId || 'agent_techpulse_default');
  const [apiResponse, setApiResponse] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedCurl, setCopiedCurl] = useState(false);

  const appUrl = window.location.origin;

  const getCurlCommand = () => {
    switch (activeEndpoint) {
      case 'init':
        return `curl -X POST "${appUrl}/api/agent/init" \\
  -H "Content-Type: application/json" \\
  -d '{"agentId": "${initAgentIdInput}", "intervalMinutes": 30, "minScoreThreshold": 75}'`;
      case 'feed':
        return `curl -X GET "${appUrl}/api/agent/feed?agentId=${feedAgentIdInput}"`;
      case 'status':
        return `curl -X GET "${appUrl}/api/agent/status"`;
      case 'trigger':
        return `curl -X POST "${appUrl}/api/agent/trigger" \\
  -H "Content-Type: application/json" \\
  -d '{"agentId": "${feedAgentIdInput}"}'`;
    }
  };

  const handleCopyCurl = () => {
    navigator.clipboard.writeText(getCurlCommand());
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  const handleTestApi = async () => {
    setIsLoading(true);
    setApiResponse(null);
    try {
      let res: Response;
      if (activeEndpoint === 'init') {
        res = await fetch('/api/agent/init', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            agentId: initAgentIdInput || undefined,
            intervalMinutes: 30,
            minScoreThreshold: 75,
          }),
        });
      } else if (activeEndpoint === 'feed') {
        res = await fetch(`/api/agent/feed?agentId=${encodeURIComponent(feedAgentIdInput)}`);
      } else if (activeEndpoint === 'status') {
        res = await fetch('/api/agent/status');
      } else {
        res = await fetch('/api/agent/trigger', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ agentId: feedAgentIdInput }),
        });
      }

      const data = await res.json();
      setApiResponse(data);
    } catch (e: any) {
      setApiResponse({ error: e.message || 'API request failed' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl border border-cyan-500/20 bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold tracking-wider uppercase mb-1">
              <Terminal className="h-4 w-4" />
              <span>Hackathon REST API Specifications</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-100">Interactive REST API Explorer</h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Test the exact endpoints required by the problem statement: <code className="text-cyan-300 font-mono">POST /api/agent/init</code> and <code className="text-cyan-300 font-mono">GET /api/agent/feed?agentId=...</code>.
            </p>
          </div>
        </div>

        {/* Endpoint Selector Tabs */}
        <div className="mt-6 flex flex-wrap gap-2 pt-4 border-t border-slate-800">
          {[
            { id: 'init', method: 'POST', path: '/api/agent/init', desc: 'Initialize Persona' },
            { id: 'feed', method: 'GET', path: '/api/agent/feed', desc: 'Get Published Feed' },
            { id: 'status', method: 'GET', path: '/api/agent/status', desc: 'Agent Status' },
            { id: 'trigger', method: 'POST', path: '/api/agent/trigger', desc: 'Trigger Cycle' },
          ].map(ep => (
            <button
              key={ep.id}
              onClick={() => {
                setActiveEndpoint(ep.id as any);
                setApiResponse(null);
              }}
              className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-mono transition-all ${
                activeEndpoint === ep.id
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'bg-slate-800/60 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${ep.method === 'POST' ? 'bg-purple-950 text-purple-300' : 'bg-emerald-950 text-emerald-300'}`}>
                {ep.method}
              </span>
              <span>{ep.path}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Tester Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Inputs & cURL generator */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-200 flex items-center justify-between border-b border-slate-800 pb-3">
            <span>Request Configuration</span>
            <button
              onClick={handleCopyCurl}
              className="flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-mono"
            >
              {copiedCurl ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copiedCurl ? 'Copied cURL' : 'Copy cURL'}</span>
            </button>
          </h3>

          {/* Dynamic Input Fields */}
          {activeEndpoint === 'init' && (
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">Agent ID (agentId)</label>
              <input
                type="text"
                value={initAgentIdInput}
                onChange={e => setInitAgentIdInput(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
              />
            </div>
          )}

          {(activeEndpoint === 'feed' || activeEndpoint === 'trigger') && (
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">Target Agent ID (agentId query param)</label>
              <input
                type="text"
                value={feedAgentIdInput}
                onChange={e => setFeedAgentIdInput(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
              />
            </div>
          )}

          {/* cURL Command Codebox */}
          <div className="space-y-1">
            <span className="text-[11px] font-mono text-slate-400">cURL Command:</span>
            <pre className="rounded-xl border border-slate-800 bg-slate-950 p-3.5 text-[11px] font-mono text-cyan-300 overflow-x-auto whitespace-pre-wrap">
              {getCurlCommand()}
            </pre>
          </div>

          <button
            onClick={handleTestApi}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 py-2.5 text-xs font-bold text-slate-950 hover:from-cyan-400 hover:to-blue-500 transition-all shadow-md shadow-cyan-500/20 disabled:opacity-50"
          >
            {isLoading ? (
              <span className="animate-spin h-4 w-4 border-2 border-slate-950 border-t-transparent rounded-full" />
            ) : (
              <Send className="h-4 w-4 text-slate-950" />
            )}
            <span>{isLoading ? 'Executing Request...' : 'Send Live API Request'}</span>
          </button>
        </div>

        {/* Right: Response Preview */}
        <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Code className="h-4 w-4 text-emerald-400" />
              <span>Live API Response</span>
            </h3>
            {apiResponse && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                200 OK
              </span>
            )}
          </div>

          <div className="font-mono text-[11px] max-h-96 overflow-y-auto no-scrollbar">
            {!apiResponse ? (
              <div className="text-slate-600 py-12 text-center">
                Click "Send Live API Request" to execute endpoint and view live JSON output.
              </div>
            ) : (
              <pre className="text-slate-200 whitespace-pre-wrap">
                {JSON.stringify(apiResponse, null, 2)}
              </pre>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
