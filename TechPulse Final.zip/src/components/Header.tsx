import React from 'react';
import { Activity, Rss, Layers, ShieldCheck, Terminal, Sparkles, RefreshCw, UserCheck, Shield } from 'lucide-react';
import { AgentState } from '../types';
import { User } from '@supabase/supabase-js';

interface HeaderProps {
  agentState: AgentState | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onTriggerCycle: () => void;
  isTriggering: boolean;
  user: User | null;
  onOpenAuth: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  agentState,
  activeTab,
  setActiveTab,
  onTriggerCycle,
  isTriggering,
  user,
  onOpenAuth,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-[#0F172A]">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        {/* Brand & Persona Geometric Badge */}
        <div className="flex items-center gap-4">
          <div className="relative flex h-8 w-8 items-center justify-center rounded-sm bg-cyan-500 rotate-45 shadow-md shadow-cyan-500/20">
            <div className="h-4 w-4 rounded-sm bg-[#0B0E14]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white">
                TECHPULSE <span className="text-cyan-400 font-light">AI</span>
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 border border-cyan-500/30 rounded text-[10px] text-cyan-400 uppercase tracking-widest font-mono">
                Autonomous Agent v2.4.1
              </span>
            </div>
          </div>
        </div>

        {/* Center Navigation Tabs */}
        <nav className="hidden lg:flex items-center gap-1 rounded-md border border-slate-800 bg-[#0D1117] p-1">
          {[
            { id: 'feed', label: 'Published Feed', icon: Rss },
            { id: 'control', label: 'Agent Control', icon: Activity },
            { id: 'editorial', label: 'Editorial Matrix', icon: ShieldCheck },
            { id: 'memory', label: 'Memory Engine', icon: Layers },
            { id: 'api', label: 'REST API Tester', icon: Terminal },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 rounded px-3 py-1.5 text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Status Indicator, Supabase Auth & Instant Trigger Button */}
        <div className="flex items-center gap-3">
          {/* Status Badge */}
          <div className="hidden sm:flex flex-col items-end text-right pr-2">
            <span className="text-[10px] uppercase text-slate-500 tracking-wider font-semibold">Status</span>
            <span className="text-xs text-emerald-400 flex items-center gap-1.5 font-mono">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
              {agentState?.status?.toUpperCase() || 'EXECUTING_CYCLE'}
            </span>
          </div>

          {/* Supabase Auth Button */}
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-1.5 rounded border border-slate-800 bg-[#0D1117] px-2.5 py-1.5 text-xs text-slate-300 hover:border-cyan-500/50 hover:text-cyan-300 transition-all"
            title="Supabase Auth Credentials"
          >
            {user ? (
              <UserCheck className="h-3.5 w-3.5 text-emerald-400" />
            ) : (
              <Shield className="h-3.5 w-3.5 text-cyan-400" />
            )}
            <span className="hidden md:inline font-mono text-[11px]">
              {user ? 'Authenticated' : 'Supabase Auth'}
            </span>
          </button>

          {/* Trigger Cycle Button */}
          <button
            onClick={onTriggerCycle}
            disabled={isTriggering}
            className="flex items-center gap-2 rounded bg-cyan-500 px-3 py-1.5 text-xs font-bold text-slate-950 shadow-sm shadow-cyan-500/30 transition-all hover:bg-cyan-400 disabled:opacity-50 active:scale-95"
          >
            {isTriggering ? (
              <RefreshCw className="h-3.5 w-3.5 animate-spin text-slate-950" />
            ) : (
              <Sparkles className="h-3.5 w-3.5 text-slate-950" />
            )}
            <span>{isTriggering ? 'Executing...' : 'Run Cycle'}</span>
          </button>
        </div>
      </div>

      {/* Mobile Navigation Tabs */}
      <div className="flex lg:hidden overflow-x-auto border-t border-slate-800 px-2 py-1.5 no-scrollbar bg-[#0D1117]">
        {[
          { id: 'feed', label: 'Feed', icon: Rss },
          { id: 'control', label: 'Control', icon: Activity },
          { id: 'editorial', label: 'Editorial', icon: ShieldCheck },
          { id: 'memory', label: 'Memory', icon: Layers },
          { id: 'api', label: 'REST API', icon: Terminal },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 whitespace-nowrap rounded px-3 py-1 text-xs font-medium ${
                isActive ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400'
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {tab.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};

