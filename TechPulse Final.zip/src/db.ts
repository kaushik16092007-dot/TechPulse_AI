import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { PublishedPost, CandidateTopic, AgentState, MemoryNode, LogEntry } from './types.js';

const DB_FILE_PATH = path.join(process.cwd(), 'techpulse.sqlite');

let db: Database | null = null;

export async function getDb(): Promise<Database> {
  if (db) return db;

  const SQL = await initSqlJs();

  if (fs.existsSync(DB_FILE_PATH)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE_PATH);
      db = new SQL.Database(fileBuffer);
    } catch (e) {
      console.error('Failed to read existing SQLite database file, initializing new DB:', e);
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
  }

  // Ensure tables exist
  db.run(`
    CREATE TABLE IF NOT EXISTS agent_state (
      agent_id TEXT PRIMARY KEY,
      name TEXT,
      persona_title TEXT,
      status TEXT,
      initialized_at TEXT,
      last_run_at TEXT,
      next_run_at TEXT,
      interval_minutes INTEGER,
      min_score_threshold INTEGER,
      total_runs INTEGER,
      total_published INTEGER,
      total_rejected INTEGER,
      domain_focus TEXT
    );

    CREATE TABLE IF NOT EXISTS posts (
      id TEXT PRIMARY KEY,
      agent_id TEXT,
      timestamp TEXT,
      title TEXT,
      headline TEXT,
      explanation TEXT,
      technical_insights TEXT,
      persona_opinion TEXT,
      future_implications TEXT,
      conclusion TEXT,
      full_content TEXT,
      rationale_json TEXT,
      sources_json TEXT,
      category TEXT,
      word_count INTEGER,
      ref_post_id TEXT,
      ref_post_title TEXT
    );

    CREATE TABLE IF NOT EXISTS candidates (
      id TEXT PRIMARY KEY,
      title TEXT,
      summary TEXT,
      source_name TEXT,
      source_url TEXT,
      discovered_at TEXT,
      category TEXT,
      criteria_json TEXT,
      total_score REAL,
      status TEXT,
      rejection_reason TEXT
    );

    CREATE TABLE IF NOT EXISTS memory_nodes (
      id TEXT PRIMARY KEY,
      topic_summary TEXT,
      category TEXT,
      keywords_json TEXT,
      timestamp TEXT,
      published_post_id TEXT,
      headline TEXT
    );

    CREATE TABLE IF NOT EXISTS logs (
      id TEXT PRIMARY KEY,
      agent_id TEXT,
      timestamp TEXT,
      level TEXT,
      action TEXT,
      message TEXT,
      details_json TEXT
    );
  `);

  saveDb();
  return db;
}

export function saveDb(): void {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE_PATH, buffer);
  } catch (e) {
    console.error('Error saving SQLite database to disk:', e);
  }
}

// Helper methods for Agent State
export async function getAgentState(agentId?: string): Promise<AgentState | null> {
  const database = await getDb();
  let query = 'SELECT * FROM agent_state';
  let params: any[] = [];
  if (agentId) {
    query += ' WHERE agent_id = ?';
    params.push(agentId);
  }
  query += ' LIMIT 1';

  const stmt = database.prepare(query);
  if (params.length > 0) stmt.bind(params);

  if (stmt.step()) {
    const row = stmt.getAsObject();
    stmt.free();
    return {
      agentId: row.agent_id as string,
      name: row.name as string,
      personaTitle: row.persona_title as string,
      status: row.status as any,
      initializedAt: row.initialized_at as string,
      lastRunAt: (row.last_run_at as string) || null,
      nextRunAt: (row.next_run_at as string) || null,
      intervalMinutes: row.interval_minutes as number,
      minScoreThreshold: row.min_score_threshold as number,
      totalRunsCount: row.total_runs as number,
      totalPostsPublished: row.total_published as number,
      totalTopicsRejected: row.total_rejected as number,
      currentDomainFocus: row.domain_focus as string,
    };
  }
  stmt.free();
  return null;
}

export async function saveAgentState(state: AgentState): Promise<void> {
  const database = await getDb();
  database.run(
    `INSERT OR REPLACE INTO agent_state (
      agent_id, name, persona_title, status, initialized_at, last_run_at, next_run_at,
      interval_minutes, min_score_threshold, total_runs, total_published, total_rejected, domain_focus
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      state.agentId,
      state.name,
      state.personaTitle,
      state.status,
      state.initializedAt,
      state.lastRunAt,
      state.nextRunAt,
      state.intervalMinutes,
      state.minScoreThreshold,
      state.totalRunsCount,
      state.totalPostsPublished,
      state.totalTopicsRejected,
      state.currentDomainFocus,
    ]
  );
  saveDb();
}

// Posts helper methods
export async function insertPost(post: PublishedPost): Promise<void> {
  const database = await getDb();
  database.run(
    `INSERT OR REPLACE INTO posts (
      id, agent_id, timestamp, title, headline, explanation, technical_insights,
      persona_opinion, future_implications, conclusion, full_content, rationale_json,
      sources_json, category, word_count, ref_post_id, ref_post_title
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      post.id,
      post.agentId,
      post.timestamp,
      post.title,
      post.headline,
      post.explanation,
      post.technicalInsights,
      post.personaOpinion,
      post.futureImplications,
      post.conclusion,
      post.fullContent,
      JSON.stringify(post.rationale),
      JSON.stringify(post.sources),
      post.category,
      post.wordCount,
      post.referencesPreviousPostId || null,
      post.referencesPreviousPostTitle || null,
    ]
  );

  // Also insert into memory_nodes
  database.run(
    `INSERT OR REPLACE INTO memory_nodes (
      id, topic_summary, category, keywords_json, timestamp, published_post_id, headline
    ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      `mem_${post.id}`,
      post.headline + ' - ' + post.explanation.substring(0, 150),
      post.category,
      JSON.stringify([post.category, ...post.title.toLowerCase().split(' ')]),
      post.timestamp,
      post.id,
      post.headline,
    ]
  );

  saveDb();
}

export async function getFeedPosts(agentId?: string): Promise<PublishedPost[]> {
  const database = await getDb();
  let query = 'SELECT * FROM posts';
  let params: any[] = [];
  if (agentId) {
    query += ' WHERE agent_id = ?';
    params.push(agentId);
  }
  query += ' ORDER BY timestamp DESC';

  const stmt = database.prepare(query);
  if (params.length > 0) stmt.bind(params);

  const posts: PublishedPost[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject();
    posts.push({
      id: row.id as string,
      agentId: row.agent_id as string,
      timestamp: row.timestamp as string,
      title: row.title as string,
      headline: row.headline as string,
      explanation: row.explanation as string,
      technicalInsights: row.technical_insights as string,
      personaOpinion: row.persona_opinion as string,
      futureImplications: row.future_implications as string,
      conclusion: row.conclusion as string,
      fullContent: row.full_content as string,
      rationale: JSON.parse((row.rationale_json as string) || '{}'),
      sources: JSON.parse((row.sources_json as string) || '[]'),
      category: row.category as string,
      wordCount: row.word_count as number,
      referencesPreviousPostId: (row.ref_post_id as string) || undefined,
      referencesPreviousPostTitle: (row.ref_post_title as string) || undefined,
    });
  }
  stmt.free();
  return posts;
}

// Candidates helper methods
export async function insertCandidate(candidate: CandidateTopic): Promise<void> {
  const database = await getDb();
  database.run(
    `INSERT OR REPLACE INTO candidates (
      id, title, summary, source_name, source_url, discovered_at, category,
      criteria_json, total_score, status, rejection_reason
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      candidate.id,
      candidate.title,
      candidate.summary,
      candidate.sourceName,
      candidate.sourceUrl,
      candidate.discoveredAt,
      candidate.category,
      JSON.stringify(candidate.criteriaScores),
      candidate.totalScore,
      candidate.status,
      candidate.rejectionReason || null,
    ]
  );
  saveDb();
}

export async function getCandidates(status?: string): Promise<CandidateTopic[]> {
  const database = await getDb();
  let query = 'SELECT * FROM candidates';
  let params: any[] = [];
  if (status) {
    query += ' WHERE status = ?';
    params.push(status);
  }
  query += ' ORDER BY discovered_at DESC LIMIT 50';

  const stmt = database.prepare(query);
  if (params.length > 0) stmt.bind(params);

  const candidates: CandidateTopic[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject();
    candidates.push({
      id: row.id as string,
      title: row.title as string,
      summary: row.summary as string,
      sourceName: row.source_name as string,
      sourceUrl: row.source_url as string,
      discoveredAt: row.discovered_at as string,
      category: row.category as string,
      criteriaScores: JSON.parse((row.criteria_json as string) || '{}'),
      totalScore: row.total_score as number,
      status: row.status as any,
      rejectionReason: (row.rejection_reason as string) || undefined,
    });
  }
  stmt.free();
  return candidates;
}

// Memory nodes
export async function getMemoryNodes(): Promise<MemoryNode[]> {
  const database = await getDb();
  const stmt = database.prepare('SELECT * FROM memory_nodes ORDER BY timestamp DESC');
  const nodes: MemoryNode[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject();
    nodes.push({
      id: row.id as string,
      topicSummary: row.topic_summary as string,
      category: row.category as string,
      keywords: JSON.parse((row.keywords_json as string) || '[]'),
      timestamp: row.timestamp as string,
      publishedPostId: row.published_post_id as string,
      headline: row.headline as string,
    });
  }
  stmt.free();
  return nodes;
}

// Logging
export async function addLog(agentId: string, level: 'info' | 'warn' | 'error' | 'success', action: string, message: string, details?: any): Promise<void> {
  const database = await getDb();
  const id = `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  const timestamp = new Date().toISOString();
  database.run(
    `INSERT INTO logs (id, agent_id, timestamp, level, action, message, details_json) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [id, agentId, timestamp, level, action, message, details ? JSON.stringify(details) : null]
  );
  saveDb();
}

export async function getLogs(limit: number = 100): Promise<LogEntry[]> {
  const database = await getDb();
  const stmt = database.prepare('SELECT * FROM logs ORDER BY timestamp DESC LIMIT ?');
  stmt.bind([limit]);
  const logs: LogEntry[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject();
    logs.push({
      id: row.id as string,
      agentId: row.agent_id as string,
      timestamp: row.timestamp as string,
      level: row.level as any,
      action: row.action as string,
      message: row.message as string,
      details: row.details_json ? JSON.parse(row.details_json as string) : undefined,
    });
  }
  stmt.free();
  return logs;
}
