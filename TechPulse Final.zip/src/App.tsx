import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { FeedView } from './components/FeedView';
import { AgentControl } from './components/AgentControl';
import { EditorialRoom } from './components/EditorialRoom';
import { MemoryAnalytics } from './components/MemoryAnalytics';
import { ApiExplorer } from './components/ApiExplorer';
import { AuthModal } from './components/AuthModal';
import { InteractiveBackground } from './lib/background';
import { CustomCursor } from './lib/cursor';
import { AgentState, PublishedPost, CandidateTopic, MemoryNode, LogEntry } from './types';
import { User } from '@supabase/supabase-js';
import { testFirebaseConnection } from './lib/firebase';

export default function App() {
  const [activeTab, setActiveTab] = useState('feed');
  const [agentState, setAgentState] = useState<AgentState | null>(null);
  const [posts, setPosts] = useState<PublishedPost[]>([]);
  const [candidates, setCandidates] = useState<CandidateTopic[]>([]);
  const [memoryNodes, setMemoryNodes] = useState<MemoryNode[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);

  const [isLoading, setIsLoading] = useState(true);
  const [isTriggering, setIsTriggering] = useState(false);

  // Test Firebase Firestore connection on mount
  useEffect(() => {
    testFirebaseConnection();
  }, []);

  // Supabase Auth State
  const [user, setUser] = useState<User | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  // Fetch all agent data
  const refreshData = useCallback(async () => {
    try {
      // 1. Fetch Agent Status
      const statusRes = await fetch('/api/agent/status');
      if (statusRes.ok) {
        const statusData = await statusRes.json();
        if (statusData.state) setAgentState(statusData.state);
      }

      // 2. Fetch Feed Posts
      const feedRes = await fetch('/api/agent/feed');
      if (feedRes.ok) {
        const feedData = await feedRes.json();
        if (feedData.posts) setPosts(feedData.posts);
      }

      // 3. Fetch Candidates
      const candRes = await fetch('/api/agent/candidates');
      if (candRes.ok) {
        const candData = await candRes.json();
        if (candData.candidates) setCandidates(candData.candidates);
      }

      // 4. Fetch Memory
      const memRes = await fetch('/api/agent/memory');
      if (memRes.ok) {
        const memData = await memRes.json();
        if (memData.memoryNodes) setMemoryNodes(memData.memoryNodes);
      }

      // 5. Fetch Logs
      const logsRes = await fetch('/api/agent/logs');
      if (logsRes.ok) {
        const logsData = await logsRes.json();
        if (logsData.logs) setLogs(logsData.logs);
      }
    } catch (e) {
      console.error('Error fetching TechPulse AI data:', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
    const interval = setInterval(refreshData, 10000); // Polling every 10 seconds
    return () => clearInterval(interval);
  }, [refreshData]);

  // Handle Manual Trigger
  const handleTriggerCycle = async () => {
    setIsTriggering(true);
    try {
      const res = await fetch('/api/agent/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId: agentState?.agentId }),
      });
      await res.json();
      await refreshData();
    } catch (e) {
      console.error('Error triggering autonomous cycle:', e);
    } finally {
      setIsTriggering(false);
    }
  };

  // Handle Init Agent
  const handleInitAgent = async (customId?: string, interval?: number, threshold?: number) => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/agent/init', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentId: customId,
          intervalMinutes: interval,
          minScoreThreshold: threshold,
        }),
      });
      await res.json();
      await refreshData();
    } catch (e) {
      console.error('Error initializing agent:', e);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Config Update
  const handleUpdateConfig = async (interval: number, threshold: number) => {
    try {
      await fetch('/api/agent/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ intervalMinutes: interval, minScoreThreshold: threshold }),
      });
      await refreshData();
    } catch (e) {
      console.error('Error updating config:', e);
    }
  };

  return (
    <div className="relative min-h-screen bg-[#0B0E14] text-slate-300 font-sans selection:bg-cyan-500 selection:text-slate-950 overflow-x-hidden">
      {/* Interactive Background Canvas */}
      <InteractiveBackground />

      {/* Custom Glowing Magnetic Cursor */}
      <CustomCursor />

      {/* Supabase Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        user={user}
        onUserChange={setUser}
      />

      {/* Main App Layout */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Navigation Header */}
        <Header
          agentState={agentState}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onTriggerCycle={handleTriggerCycle}
          isTriggering={isTriggering}
          user={user}
          onOpenAuth={() => setIsAuthOpen(true)}
        />

        {/* Content Container */}
        <main className="flex-1 mx-auto w-full max-w-7xl px-4 py-8 sm:px-6">
          {activeTab === 'feed' && (
            <FeedView
              posts={posts}
              agentId={agentState?.agentId || 'agent_techpulse_default'}
              isLoading={isLoading}
              onRefresh={refreshData}
            />
          )}

          {activeTab === 'control' && (
            <AgentControl
              agentState={agentState}
              logs={logs}
              onTriggerCycle={handleTriggerCycle}
              onInitAgent={handleInitAgent}
              onUpdateConfig={handleUpdateConfig}
              isTriggering={isTriggering}
            />
          )}

          {activeTab === 'editorial' && (
            <EditorialRoom
              candidates={candidates}
              minThreshold={agentState?.minScoreThreshold || 75}
            />
          )}

          {activeTab === 'memory' && (
            <MemoryAnalytics memoryNodes={memoryNodes} posts={posts} />
          )}

          {activeTab === 'api' && (
            <ApiExplorer agentId={agentState?.agentId || 'agent_techpulse_default'} />
          )}
        </main>

        {/* Custom Geometric Footer */}
        <footer className="h-10 border-t border-slate-800 px-6 flex items-center justify-between text-[10px] font-mono bg-[#0D1117] text-slate-500">
          <div className="flex gap-4">
            <span>DB: SQLITE + FIREBASE_FIRESTORE</span>
            <span>PROJECT: astral-lens-x9v0l</span>
            <span>AUTH: {user ? 'SUPABASE_AUTHENTICATED' : 'FIREBASE_GOOGLE_AVAILABLE'}</span>
          </div>
          <div className="hidden sm:flex gap-4">
            <span className="text-amber-400/90 font-mono">// FIREBASE: Rules deployed & verified (asia-southeast1)</span>
          </div>
        </footer>
      </div>
    </div>
  );
}

