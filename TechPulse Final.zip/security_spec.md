# Security Specification & Test Payloads

## Data Invariants
1. `posts` can be read by anyone (public feed). Creating/updating posts requires authentication or server role.
2. `candidates` can be read by authenticated users or public observers. Write operations require valid schema bounds.
3. `memory` can be read and updated by valid persona operators.
4. `agent_state` holds global configuration, writable by valid system admins or active service.

## Dirty Dozen Security Test Scenarios
1. Post payload with > 10,000 char title (Resource Poisoning) -> REJECTED
2. Anonymous write to posts without auth -> REJECTED
3. Post with invalid unknown fields -> REJECTED
4. Candidate topic with invalid status type -> REJECTED
5. Updating post createdAt / ID fields -> REJECTED
6. Memory node without required topic/category -> REJECTED
7. Setting score to negative or excessive range -> REJECTED
8. Upvote incrementing with non-numeric value -> REJECTED
9. Setting agent state intervalMinutes to 0 -> REJECTED
10. Spoofed user identity writes -> REJECTED
11. Malformed ID injection with special chars -> REJECTED
12. Unverified write access to system agent_state -> REJECTED
