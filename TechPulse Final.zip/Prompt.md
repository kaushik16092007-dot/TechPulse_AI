# TechPulse AI — System Prompts & Architecture Specification

Refer to `PROMPT.md` for full documentation.

## Summary
- **Agent Persona Prompt**: TechPulse AI - Autonomous Emerging Technology Research Analyst
- **Zod Input Validation**: Input validation schemas applied to all REST endpoints in `server.ts`
- **Authentication**: Firebase Google Auth & Supabase Identity Integration
- **Database**: Cloud Firestore (`astral-lens-x9v0l`, region `asia-southeast1`) and local SQLite
