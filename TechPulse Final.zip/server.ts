import express from 'express';
import cors from 'cors';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { z } from 'zod';
import { getAgentState, getFeedPosts, getCandidates, getMemoryNodes, getLogs, saveAgentState } from './src/db.js';
import { initializeAgent, runAutonomousCycle, startScheduler } from './src/services/agentRunner.js';

// ==========================================
// ZOD VALIDATION SCHEMAS
// ==========================================

const InitAgentSchema = z.object({
  agentId: z.string().trim().min(1).max(100).optional(),
  intervalMinutes: z.coerce.number().min(1).max(1440).optional(),
  minScoreThreshold: z.coerce.number().min(0).max(100).optional(),
});

const TriggerAgentSchema = z.object({
  agentId: z.string().trim().min(1).max(100).optional(),
});

const ConfigAgentSchema = z.object({
  intervalMinutes: z.coerce.number().min(1).max(1440).optional(),
  minScoreThreshold: z.coerce.number().min(0).max(100).optional(),
});

const FeedQuerySchema = z.object({
  agentId: z.string().trim().min(1).max(100).optional(),
});

const CandidateQuerySchema = z.object({
  status: z.string().trim().optional(),
});

const LogsQuerySchema = z.object({
  limit: z.coerce.number().min(1).max(500).optional(),
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // Auto-boot agent state if present on server start
  try {
    const existingState = await getAgentState();
    if (existingState) {
      console.log(`Server Startup: Re-instantiating existing agent ${existingState.agentId}...`);
      startScheduler(existingState.agentId, existingState.intervalMinutes);
    } else {
      console.log(`Server Startup: Seeding initial agent persona...`);
      await initializeAgent('agent_techpulse_default');
    }
  } catch (e) {
    console.error('Error auto-booting agent state on server startup:', e);
  }

  // ==========================================
  // REQUIRED REST API ENDPOINTS
  // ==========================================

  // 1. POST /api/agent/init
  app.post('/api/agent/init', async (req, res) => {
    try {
      const parseResult = InitAgentSchema.safeParse(req.body || {});
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: 'Validation Error: Invalid input parameters for agent initialization',
          details: parseResult.error.flatten(),
        });
      }

      const { agentId, intervalMinutes, minScoreThreshold } = parseResult.data;
      const agentState = await initializeAgent(agentId, {
        intervalMinutes,
        minScoreThreshold,
      });

      res.status(200).json({
        success: true,
        agentId: agentState.agentId,
        status: agentState.status,
        message: 'TechPulse AI autonomous agent persona successfully initialized. Scheduler active.',
        initializedAt: agentState.initializedAt,
        config: {
          intervalMinutes: agentState.intervalMinutes,
          minScoreThreshold: agentState.minScoreThreshold,
          autoRunEnabled: true,
          domainFocuses: ['Machine Learning', 'Robotics', 'Edge AI', 'Open Source AI', 'AI Hardware', 'AI Security'],
        },
      });
    } catch (error: any) {
      console.error('Error in /api/agent/init:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to initialize AI agent persona',
      });
    }
  });

  // 2. GET /api/agent/feed
  app.get('/api/agent/feed', async (req, res) => {
    try {
      const parseResult = FeedQuerySchema.safeParse(req.query);
      if (!parseResult.success) {
        return res.status(400).json({
          error: 'Validation Error: Invalid query parameters',
          details: parseResult.error.flatten(),
        });
      }

      const agentIdParam = parseResult.data.agentId;
      const posts = await getFeedPosts(agentIdParam);
      const state = await getAgentState(agentIdParam);

      res.status(200).json({
        agentId: state?.agentId || agentIdParam || 'agent_techpulse_default',
        count: posts.length,
        posts,
      });
    } catch (error: any) {
      console.error('Error in /api/agent/feed:', error);
      res.status(500).json({
        error: error.message || 'Failed to fetch agent feed',
      });
    }
  });

  // ==========================================
  // DASHBOARD & INSPECTION ENDPOINTS
  // ==========================================

  // GET /api/agent/status
  app.get('/api/agent/status', async (req, res) => {
    try {
      const state = await getAgentState();
      if (!state) {
        return res.status(404).json({ error: 'Agent not initialized. Call POST /api/agent/init first.' });
      }

      res.status(200).json({
        success: true,
        state,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/agent/trigger - Manually trigger an immediate autonomous cycle
  app.post('/api/agent/trigger', async (req, res) => {
    try {
      const parseResult = TriggerAgentSchema.safeParse(req.body || {});
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: 'Validation Error: Invalid request body',
          details: parseResult.error.flatten(),
        });
      }

      const { agentId } = parseResult.data;
      const result = await runAutonomousCycle(agentId);

      res.status(200).json({
        success: true,
        message: result.logMessage,
        publishedPost: result.publishedPost,
        evaluatedCount: result.evaluatedCount,
        rejectedCount: result.rejectedCount,
      });
    } catch (error: any) {
      console.error('Error in /api/agent/trigger:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to trigger autonomous cycle',
      });
    }
  });

  // GET /api/agent/candidates
  app.get('/api/agent/candidates', async (req, res) => {
    try {
      const parseResult = CandidateQuerySchema.safeParse(req.query);
      if (!parseResult.success) {
        return res.status(400).json({
          error: 'Validation Error: Invalid query parameters',
          details: parseResult.error.flatten(),
        });
      }

      const status = parseResult.data.status;
      const candidates = await getCandidates(status);
      res.status(200).json({
        count: candidates.length,
        candidates,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/agent/rejected
  app.get('/api/agent/rejected', async (req, res) => {
    try {
      const candidates = await getCandidates('rejected');
      res.status(200).json({
        count: candidates.length,
        rejectedTopics: candidates,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/agent/memory
  app.get('/api/agent/memory', async (req, res) => {
    try {
      const nodes = await getMemoryNodes();
      res.status(200).json({
        totalNodes: nodes.length,
        memoryNodes: nodes,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/agent/logs
  app.get('/api/agent/logs', async (req, res) => {
    try {
      const parseResult = LogsQuerySchema.safeParse(req.query);
      if (!parseResult.success) {
        return res.status(400).json({
          error: 'Validation Error: Invalid query parameters',
          details: parseResult.error.flatten(),
        });
      }

      const limit = parseResult.data.limit || 50;
      const logs = await getLogs(limit);
      res.status(200).json({
        count: logs.length,
        logs,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/agent/config
  app.post('/api/agent/config', async (req, res) => {
    try {
      const parseResult = ConfigAgentSchema.safeParse(req.body || {});
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: 'Validation Error: Invalid configuration body',
          details: parseResult.error.flatten(),
        });
      }

      const { intervalMinutes, minScoreThreshold } = parseResult.data;
      const state = await getAgentState();
      if (state) {
        if (intervalMinutes !== undefined) state.intervalMinutes = intervalMinutes;
        if (minScoreThreshold !== undefined) state.minScoreThreshold = minScoreThreshold;
        await saveAgentState(state);
        startScheduler(state.agentId, state.intervalMinutes);
      }
      res.status(200).json({ success: true, state });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });


  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'TechPulse AI Engine', timestamp: new Date().toISOString() });
  });

  // Vite Middleware in development mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TechPulse AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
